# ElaxticSearch Notes

